clear
echo -e "\nENTER FIRST NUMBER"
read a
echo -e "\nENTER LAST NUMBER"
read b
while [ $a -le $b ]
do
	echo $a
	((a++))
done
