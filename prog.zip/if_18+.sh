clear
echo -e "\nENTER YOUR AGE"
read a
if test $a -ge 18
then
	echo "YOUR AGE IS $a AND VALID"
else
	echo "YOUR AGE IS $a AND NOT VALID"
fi
