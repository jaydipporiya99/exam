clear

echo -e "\nENTER A"
read a

echo -e "\nENTER B"
read b

if cmp -s $a $b
then
	echo "SAME"
else
	echo "NOT"
fi
