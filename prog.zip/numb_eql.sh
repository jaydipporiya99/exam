clear
echo -e "\nENTER A"
read a
echo -e "\nENTER B"
read b
if test $a -eq $b
then
	echo "EQUAL"
else
	echo "NOT"
fi
