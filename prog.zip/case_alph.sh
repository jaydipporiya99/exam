clear
echo -e "\nENTER YOUR CHOICE"
read a
case $a in
	[0-9]) echo "NUMBER"
		;;
	[a-zA-Z]) echo "ALPHABET"
		;;
	*) echo "SPECIAL CHARACTER"
		;;
esac
