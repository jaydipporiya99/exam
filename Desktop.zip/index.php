<?php

include "connect.php";

if (isset($_POST['add'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $hobby = implode(",", $_POST['hobby']);
    $gender = $_POST['gender'];

    $insert = "INSERT INTO `user`(`name`, `email`, `pass`, `hobby`, `gender`) VALUES ('$name','$email','$pass','$hobby','$gender')";

    $run = $cn->query($insert);

}

if (isset($_POST['update'])) {

    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $hobby = implode(",", $_POST['hobby']);
    $gender = $_POST['gender'];

    $update = "UPDATE `user` SET `name`='$name',`email`='$email',`pass`='$pass',`hobby`='$hobby',`gender`='$gender' WHERE id = $_GET[edit]";

    $run = $cn->query($update);

}


if(isset($_GET['edit']))
{
    $sel = "select * from user";
    $run = $cn->query($sel);
    $row = mysqli_fetch_array($run);
}

if(isset($_GET['del']))
{
    $delete = "DELETE FROM `user` WHERE id = $_GET[del]";
    $run = $cn->query($delete);
    header("Location:index.php");
}



?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME</title>
</head>

<body>
    <div>
        <center>
            <form method="POST">
                <table border="3">
                    <tr>
                        <th colspan="2">
                            <h1>USER DATA</h1>
                        </th>
                    </tr>
                    <tr>
                        <td>
                            <label for="name">USER NAME</label>
                        </td>
                        <td>
                            <input name="name" type="text"  value="<?php if(isset($_GET['edit'])) echo $row['name'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="email">USER EMAIL</label>
                        </td>
                        <td>
                            <input name="email" type="email"    value="<?php if(isset($_GET['edit'])) echo $row['email'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="pass">USER PASS</label>
                        </td>
                        <td>
                            <input name="pass" type="password"  value="<?php if(isset($_GET['edit'])) echo $row['pass'] ?>">
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="pass">HOBBY</label>
                        </td>
                        <td>
                            <input type="checkbox" id="dance" name="hobby[]" value="DANCING">
                            <label for="dance">DANCING</label>
                            <input type="checkbox" id="read" name="hobby[]" value="READING">
                            <label for="read">READING</label>
                            <input type="checkbox" id="write" name="hobby[]" value="WRITING">
                            <label for="write">WRITING</label>
                            <input type="checkbox" id="fight" name="hobby[]" value="FIGHTING">
                            <label for="fight">FIGHTING</label>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <label for="">GENDER</label>
                        </td>
                        <td>
                            <input type="radio" id="male" name="gender" value="MALE">
                            <label for="male">MALE</label>

                            <input type="radio" id="female" name="gender" value="FEMALE">
                            <label for="female">FEMALE</label>
                        </td>
                    </tr>
                    <tr>
                        <td colspan="2">
                            <center>
                            <?php 
                            
                                if(isset($_GET['edit']))
                                {
                                ?>
                                <button name="update">UPDATE</button>
                            <?php
                                }
                                else{
                            ?>
                                <button name="add">ADD</button>
                                <button type="reset" name="clear">CLEAR</button>
                            <?php 
                                }
                            ?>

                            </center>
                        </td>
                    </tr>
                </table>
            </form>
        </center>
    </div>

    <!-- --------------------------------------------- -->
    <br>
    <br>

    <div>
        <center>
            <form method="POST">
                <input type="text" name="find">
                <button name="search">SEARCH</button>
            </form>
        </center>
    </div>
    <br><br>
    <div>
        <center>
            <table border="4">
                <tr>
                    <th>ID</th>
                    <th>USER NAME</th>
                    <th>USER EMAIL</th>
                    <th>PASSWORD</th>
                    <th>HOBBY</th>
                    <th>GENDER</th>
                    <th>ACTION</th>
                </tr>
                <?php
                if (isset($_POST['search'])) {

                    $find = $_POST['find'];
                    $sel = "SELECT * FROM `user` WHERE name like '%$find%' OR gender like '%$find%'";
                    $run = $cn->query($sel);

                    $count = mysqli_num_rows($run);

                    if ($count > 0) {
                        while ($row = mysqli_fetch_array($run)) {
                            ?>
                            <tr>
                                <td>
                                    <?php echo $row['id'] ?>
                                </td>
                                <td>
                                    <?php echo $row['name'] ?>
                                </td>
                                <td>
                                    <?php echo $row['email'] ?>
                                </td>
                                <td>
                                    <?php echo $row['pass'] ?>
                                </td>
                                <td>
                                    <?php echo $row['hobby'] ?>
                                </td>
                                <td>
                                    <?php echo $row['gender'] ?>
                                </td>
                                <td>
                                    <a href="index.php?edit=<?php echo $row['id'] ?>"><button>EDIT</button></a>
                                    <a href="index.php?del=<?php echo $row['id'] ?>"><button
                                            onclick="return confirm('WANT TO DELETE');">DELETE</button></a>
                                </td>
                            </tr>

                            <?php
                        }
                    } else {
                        echo "RECORD NOT FOUND";
                    }
                } else {

                    $sel = "SELECT * FROM `user`";
                    $run = $cn->query($sel);
                    while ($row = mysqli_fetch_array($run)) {
                        ?>
                        <tr>
                            <td>
                                <?php echo $row['id'] ?>
                            </td>
                            <td>
                                <?php echo $row['name'] ?>
                            </td>
                            <td>
                                <?php echo $row['email'] ?>
                            </td>
                            <td>
                                <?php echo $row['pass'] ?>
                            </td>
                            <td>
                                <?php echo $row['hobby'] ?>
                            </td>
                            <td>
                                <?php echo $row['gender'] ?>
                            </td>
                            <td>
                                <a href="index.php?edit=<?php echo $row['id'] ?>"><button>EDIT</button></a>
                                <a href="index.php?del=<?php echo $row['id'] ?>"><button
                                        onclick="return confirm('WANT TO DELETE');">DELETE</button></a>
                            </td>
                        </tr>

                        <?php
                    }
                }
                ?>
            </table>
        </center>
    </div>
</body>

</html>