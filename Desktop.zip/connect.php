<?php 

    $hname = "localhost";
    $uname = "root";
    $pass = "";
    $db = "exam";

    $cn = mysqli_connect($hname,$uname,$pass,$db);

    if(!$cn)
    {
        echo "ERROR";
    }

?>